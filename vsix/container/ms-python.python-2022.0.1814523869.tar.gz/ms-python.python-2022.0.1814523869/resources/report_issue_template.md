<!-- Please fill in all XXX markers -->
# Behaviour
## Expected vs. Actual

XXX

## Steps to reproduce:

1. XXX

<!--
**After** creating the issue on GitHub, you can add screenshots and GIFs of what is happening. Consider tools like https://www.cockos.com/licecap/, https://github.com/phw/peek or https://www.screentogif.com/ for GIF creation.
-->

<!-- **NOTE**: Everything below is auto-generated; no editing required. -->
# Diagnostic data

-   Python version (& distribution if applicable, e.g. Anaconda): {0}
-   Type of virtual environment used (e.g. conda, venv, virtualenv, etc.): {1}
-   Value of the `python.languageServer` setting: {2}

<details>

<summary>User Settings</summary>

<p>

```
{3}
```

</p>
</details>
